import HorizontalBarChart from "../components/HorizontalBarChart";
export default function ReportPage1(){
 return <div><h1>Page1</h1><HorizontalBarChart labels={['A','B']} data={[10,20]}/></div>
}