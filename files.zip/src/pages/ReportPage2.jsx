import HorizontalBarChart from "../components/HorizontalBarChart";
export default function ReportPage2(){
 return <div><h1>Page2</h1><HorizontalBarChart labels={['C','D']} data={[15,25]}/></div>
}