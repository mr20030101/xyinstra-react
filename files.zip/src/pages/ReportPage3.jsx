import HorizontalBarChart from "../components/HorizontalBarChart";
export default function ReportPage3(){
 return <div><h1>Page3</h1><HorizontalBarChart labels={['E','F']} data={[5,12]}/></div>
}